module.exports = function() {

    describe("Container for all of the states", function() {
        require('./state.not-authorized.test.js')();
    });

};
